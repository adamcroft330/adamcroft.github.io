Themis 35 (CineLog35 V2, themis35-cl35-r1) - CAD export (28 Oct 2026)

Units are millimetres. The origin is the centre of the carbon plate's top face,
+Z is up and the nose points to -Y.

cl35-assembly.step                full assembly, every modelled part
parts/                            watertight STL of each printed and carbon part, one file per instance
plate/cl35-arm-plate-drilling.dxf arm plate with the four Ø3.2 mm holes to drill
cl35-bom.csv, .json               bill of materials: sources, sizes, materials, masses (per drone)
cl35-validation.json              geometry checks, mass budget and track margins

Print notes are in the Material column of the BOM.
Status: Draft. Frame modelled from GEPRC's published figures and photos; guard height and plate outline unmeasured.
Interactive model: https://adamcroft.me/themis/cad/#cl35
