Themis 35 (Custom frame, themis35-r3) - CAD export (28 Oct 2026)

Units are millimetres. The origin is the centre of the carbon plate's top face,
+Z is up and the nose points to -Y.

themis35-assembly.step            full assembly, every modelled part
parts/                            watertight STL of each printed and carbon part, one file per instance
plate/themis35-carbon-plate.dxf   carbon plate outline and holes (top face)
themis35-bom.csv, .json           bill of materials: sources, sizes, materials, masses (per drone)
themis35-validation.json          geometry checks, mass budget and track margins

Print notes are in the Material column of the BOM.
Status: Concept geometry checked in CAD; not a released flight build. Thrust, structure and delivered-part fit are unmeasured.
Interactive model: https://adamcroft.me/themis/cad/
