# AVA v2 — corrected 166 mm frame comparison

The new design has four motor/duct centres at **[±41.5, ±41.5] mm**, **166 × 166 mm** overall frame size, 79 mm minimum duct ID and 82 mm nominal duct OD. Adjacent centre spacing is 83 mm. The complete model with copied payload context measures **166 × 166 × 121.1 mm**.

## Motor/frame alignment correction

The first v2 export incorrectly retained the old upper plate's motor tabs at approximately ±33.2 mm while relocating the motors. This export supersedes that version.

- The upper plate's four arms and pads are rebuilt for the new motor centres. Obsolete motor tabs are removed.
- All four 1404 concept motors seat against the plate at **z47**, restoring the original mounting datum. The upper plate remains at **z47–49**.
- Each motor has four aligned M2 clearance holes on a Ø9 mm pitch circle and four modeled M2 screws.
- The central payload mounting pattern at ±13 / ±22.8 mm, housing position and four existing heatset inserts are retained. The upper plate's outer motor arms necessarily change to match the enlarged frame.
- Motor bell: Ø19.9 × 13.5 mm; stator Ø14 × 4 mm; shaft Ø1.5 mm; full representative motor height 17 mm, z30–47.

**20 geometry checks pass**, including zero motor centre error, full support of every motor mounting face, alignment of all 16 screw bores, no motor/frame interference, prop-sweep clearance, battery margins, and preservation of the original comparison assembly. See `validation.json` for measurements.

## Battery, ducts and payload

Ducts remain at z20–47. Their 76.2 mm prop swept volumes are checked at z30–32, with 1.4 mm radial clearance. The unchanged housing floor underside is z52, giving 5 mm clearance above the ducts. The upper plate remains below the floor.

The open cradle has **75 × 42 × 30 mm internal space**, an outer tray of 79 × 46 × 32 mm, and four strap slots. Its floor spans z−12…−10; the battery check envelope spans z−8…17. Margins are 2.5 mm per X side, 2 mm per Y side, 2 mm below and 3 mm above. End supports connect to the frame between the prop swept volumes.

New propeller, battery and regulator parts remain assigned to the payload project. No electrical or propulsion-performance validation is claimed; 3.8–4:1 thrust-to-weight remains a target. The model is a packaging concept, not a fabrication-qualified frame.

## Files and coordinates

- `parts/`: **43 component STLs**, including 16 motor screws, detailed motors, the corrected upper plate, lower frame, ducts, cradle and heatsets.
- `atlas.stl`, `atlas.json`, `assets/`: packed atlas and individual binary meshes. Subtract each part's `atlasOffset` to recover its local coordinates from the packed atlas.
- `design-graph.json`, `design-spec.json`: parametric graph and dimensional definitions.
- `part-measurements.json`, `validation.json`: geometry, alignment and clearance results.
- `preview.html`, `preview-geometry.json`, `viewer/`: local comparison with the unchanged original assembly and the corrected v2.
- `source/`: generator, validator and uploader source copies. Run the maintained generators from the neighbouring Dingcad workspace using `npm run build:v2` and `npm run validate:v2`.

Units are millimetres. Individual parts use a local aircraft centre at X=Y=0 and retain the original Z datum. The comparison translates v2 by `[650,0,0]`, beside the existing Themis centre at `[390,0,0]`. STL conversion uses a 0.001 mm simplification tolerance to remove sub-resolution slivers.

`live-addition.json` and the three grouped `ava-v2-*.stl` files concern Dingcad's separate constrained renderer. This detailed correction exceeds that saved document's 12 MiB render budget, so **do not upload those grouped files to Dingcad without revalidating its limits**. That limit does not apply to the public Three.js comparison website. Nothing in this export edits the original live Dingcad assembly.
