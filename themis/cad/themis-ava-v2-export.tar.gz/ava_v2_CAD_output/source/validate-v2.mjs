import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import Module from 'manifold-3d';
import {decodeMesh,encodeMesh,parseSTL} from './vendor/dingcad/mesh-import.mjs';
const dir='themis-output/v2';
const graph=JSON.parse(fs.readFileSync(`${dir}/design-graph.json`));
const spec=JSON.parse(fs.readFileSync(`${dir}/design-spec.json`));
const baselineBytes=fs.readFileSync('themis-output/live-scene.json');
assert.equal(crypto.createHash('sha256').update(baselineBytes).digest('hex'),spec.baselineSha256,'Saved baseline changed');
const baseline=JSON.parse(baselineBytes);
const kernel=await Module();kernel.setup();const M=kernel.Manifold;
const source=new Map([...baseline.graph.nodes,...graph.nodes].map(n=>[n.id,n])),cache=new Map(),materials=new Map();
function ev(id){
 if(cache.has(id))return cache.get(id);
 const n=source.get(id);assert(n,`Missing ${id}`);const input=n.inputs.map(ev),p=n.params;let s;
 switch(n.op){
 case 'box':s=M.cube(p,true);break;
 case 'cylinder':s=M.cylinder(p[0],p[1],p[1],n.segments??32,true);break;
 case 'cone':s=M.cylinder(p[0],p[1],p[2],n.segments??32,true);break;
 case 'sphere':s=M.sphere(p[0],n.segments??32);break;
 case 'translate':s=input[0].translate(p);break;
 case 'rotate':s=input[0].rotate(p);break;
 case 'scale':s=input[0].scale(p);break;
 case 'union':s=input[0].add(input[1]);break;
 case 'difference':s=input[0].subtract(input[1]);break;
 case 'intersection':s=input[0].intersect(input[1]);break;
 case 'hull':s=M.hull(input);break;
 case 'extrude':{const cs=new kernel.CrossSection(n.profile,'EvenOdd');s=cs.extrude(p[0],0,0,[1,1],true);cs.delete();break;}
 case 'mesh':{const m=decodeMesh(new Uint8Array(fs.readFileSync(`themis-output/assets/${n.mesh}.bin`)));s=new M(new kernel.Mesh({numProp:3,vertProperties:m.vertices,triVerts:m.indices}));break;}
 default:throw Error(`Unsupported ${n.op}`);
 }
 assert.equal(s.status(),'NoError',id);
 let mat=new Map();for(const k of n.inputs)for(const [key,c]of materials.get(k)||[])mat.set(key,c);
 if(n.color){const colored=s.asOriginal();s.delete();s=colored;mat=new Map([[s.originalID(),n.color]]);}
 cache.set(id,s);materials.set(id,mat);return s;
}
function overlap(a,b){const c=a.intersect(b),v=c.volume();c.delete();return v;}
function bounds(solids){const b={min:[Infinity,Infinity,Infinity],max:[-Infinity,-Infinity,-Infinity]};for(const s of solids){const q=s.boundingBox();for(let k=0;k<3;k++){b.min[k]=Math.min(b.min[k],q.min[k]);b.max[k]=Math.max(b.max[k],q.max[k]);}}return {...b,size:b.max.map((x,k)=>x-b.min[k])};}
function stl(s){const clean=s.simplify(.001),m=clean.getMesh();const b=Buffer.alloc(84+50*m.numTri);b.write('AVA v2 concept; mm; export simplification tolerance 0.001 mm');b.writeUInt32LE(m.numTri,80);for(let t=0;t<m.numTri;t++)for(let j=0;j<3;j++)for(let k=0;k<3;k++)b.writeFloatLE(m.vertProperties[m.triVerts[t*3+j]*m.numProp+k],84+50*t+12+12*j+4*k);clean.delete();return b;}
fs.mkdirSync(`${dir}/assets`,{recursive:true});fs.mkdirSync(`${dir}/parts`,{recursive:true});
const atlas=[],preview=[],measurements=[];
for(const p of graph.parts){
 const s=ev(p.root);assert(s.numTri()>0,p.id);const b=s.boundingBox();measurements.push({id:p.id,kind:p.kind,bounds:b,triangles:s.numTri(),volumeMm3:s.volume()});
 if(p.kind!=='context'){
  const bytes=stl(s);let mesh;try{mesh=parseSTL(new Uint8Array(bytes),'mm');}catch(e){fs.writeFileSync('/tmp/ava-v2-failed.stl',bytes);throw Error(`${p.id}: ${e.message}`);}const encoded=encodeMesh(mesh),hash=crypto.createHash('sha256').update(encoded).digest('hex');
  fs.writeFileSync(`${dir}/parts/${p.id}.stl`,bytes);fs.writeFileSync(`${dir}/assets/${hash}.bin`,encoded);
  atlas.push({id:p.id,kind:p.kind,color:p.color,mesh:hash,stl:`parts/${p.id}.stl`,bounds:mesh.bounds,triangles:mesh.triangles});
 }
 const m=s.getMesh(),colors=[];let run=0;const mat=materials.get(p.root);
 for(let t=0;t<m.triVerts.length;t+=3){while(run+1<m.runOriginalID.length&&t>=m.runIndex[run+1])run++;colors.push(...(mat.get(m.runOriginalID[run])||p.color));}
 preview.push({id:p.id,color:p.color,group:p.kind==='context'?'v2-payload-context':`v2-${p.kind}`,positions:Array.from(m.vertProperties, (x,i)=>x+(i%3===0?650:0)),indices:Array.from(m.triVerts),faceColors:colors});
}
const checks=[];
const check=(name,pass,details)=>checks.push({name,pass,details});
const physical=graph.parts.filter(p=>p.kind!=='context');
const frameParts=graph.parts.filter(p=>p.kind==='frame');
const dims=bounds(physical.map(p=>ev(p.root)));
check('166 mm frame footprint',dims.size[0]===166&&dims.size[1]===166,dims);
const assembled=bounds(graph.parts.map(p=>ev(p.root)));
check('Individual assembled v2 fits 250 mm cube',assembled.size.every(x=>x<=250),assembled);
check('Duct spacing',spec.centres[1][0]-spec.centres[0][0]===83,{spacing:83,outerDiameter:82,gap:1});
let ductOverlap=0;for(let i=0;i<4;i++)for(let j=i+1;j<4;j++)ductOverlap+=overlap(ev(spec.ductRoots[i]),ev(spec.ductRoots[j]));
check('Adjacent ducts do not intersect',ductOverlap<1e-6,{intersectionMm3:ductOverlap});
const rotorHits=[];
for(let i=0;i<4;i++)for(const p of graph.parts.filter(p=>p.kind!=='prop')){const v=overlap(ev(spec.sweeps[i]),ev(p.root));if(v>1e-5)rotorHits.push({rotor:i+1,part:p.id,volumeMm3:v});}
check('3-inch swept volumes clear all geometry',rotorHits.length===0,rotorHits);
check('Minimum duct ID and prop clearance',79>=76.2+2,{minimumDuctId:79,propDiameter:76.2,diametralClearance:2.8,radialClearance:1.4});
const batteryHits=physical.filter(p=>p.kind!=='battery').map(p=>({part:p.id,volumeMm3:overlap(ev(spec.battery),ev(p.root))})).filter(p=>p.volumeMm3>1e-5);
check('Battery clears cradle and frame',batteryHits.length===0,batteryHits);
const corners=[-39,39].flatMap(x=>[-17.5,17.5].map(y=>M.cylinder(29,4,4,32,true).translate([x,y,7])));
const marginEnvelope=M.hull(corners);corners.forEach(c=>c.delete());
const marginIntrusion=physical.filter(p=>p.kind==='frame'||p.kind==='cradle').reduce((v,p)=>v+overlap(marginEnvelope,ev(p.root)),0);marginEnvelope.delete();
check('Battery cavity margins at least 2 mm',marginIntrusion<1e-5,{expandedEnvelopeIntrusionMm3:marginIntrusion,xPerSide:2,yPerSide:2,padBelow:2,internal:[86,43,29],battery:[82,39,25]});
check('Four visible three-blade propellers; two CW and two CCW',graph.parts.filter(p=>p.kind==='prop').length===4&&graph.parts.filter(p=>/prop-\d-CW-/.test(p.id)).length===2,{diameter:76.2,hubDiameter:9.8,hubHeight:4.9,bladeSurfaces:'representative purchased-part visualization'});
const plate=ev(spec.topPlateRoot);
const armOverruns=spec.centres.map(([x,y])=>{const a=Math.atan2(y,x)*180/Math.PI;const gauge=M.cube([30,16,2],true).rotate([0,0,a]).translate([x+Math.sign(x)*25/Math.SQRT2,y+Math.sign(y)*25/Math.SQRT2,48]);const v=overlap(plate,gauge);gauge.delete();return v;});
check('Motor arms terminate at pads without outer overhangs',armOverruns.every(v=>v<1e-5),armOverruns);
const rotorEnvelopes=graph.parts.filter(p=>p.kind==='prop').map((p,i)=>{
 const mesh=ev(p.root).getMesh(),[cx,cy]=spec.centres[i];let maxR=0;
 for(let k=0;k<mesh.vertProperties.length;k+=mesh.numProp)maxR=Math.max(maxR,Math.hypot(mesh.vertProperties[k]-cx,mesh.vertProperties[k+1]-cy));
 return {rotor:i+1,maxRadiusMm:maxR};
});
check('Visible blades stay inside the checked 76.2 mm envelopes',rotorEnvelopes.every(p=>p.maxRadiusMm<=38.1+1e-5),rotorEnvelopes);
const batteryBody=ev(graph.parts.find(p=>p.id==='ava-v2-battery-GNB11004S140A-1100mAh-4S').root);
const batteryContactHits=graph.parts.filter(p=>p.kind==='battery'&&!p.id.includes('GNB')).map(p=>({part:p.id,volumeMm3:overlap(batteryBody,ev(p.root))}));
check('Straps and pad contact but do not penetrate the battery',batteryContactHits.every(p=>p.volumeMm3<1e-5),batteryContactHits);
const motorMounts=graph.parts.filter(p=>/^ava-v2-motor-\d-mount$/.test(p.id));
const mountIntrusions=spec.mountHoles.map(([x,y],i)=>{const gauge=M.cylinder(4,1,1,32,true).translate([x,y,47.25]);const volume=overlap(gauge,ev(spec.topPlateRoot))+overlap(gauge,ev(motorMounts[Math.floor(i/4)].root));gauge.delete();return volume;});
check('All sixteen M2 holes align through motor bases and upper plate',mountIntrusions.every(v=>v<1e-5),{pitchCircleDiameter:9,holesPerMotor:4,intrusionMm3:mountIntrusions});
const seating= motorMounts.map((p,i)=>{
 const motor=ev(p.root),plate=ev(spec.topPlateRoot).translate([0,0,-.1]),contact=overlap(motor,plate);plate.delete();
 const shaft=ev(graph.parts.find(p=>p.id===`ava-v2-motor-${i+1}-shaft`).root).boundingBox();
 const centre=shaft.min.slice(0,2).map((x,k)=>(x+shaft.max[k])/2);
 return {motor:i+1,centre,mountFaceZ:motor.boundingBox().max[2],supportedFraction:contact/(motor.volume()/1.5*.1),centreErrorMm:Math.hypot(...centre.map((x,k)=>x-spec.centres[i][k]))};
});
check('All motors centred and fully seated at z47',seating.every(s=>s.centreErrorMm<1e-6&&s.mountFaceZ===47&&s.supportedFraction>.999),seating);
const motorFrameHits=[];
for(const p of graph.parts.filter(p=>p.kind==='motor'))for(const f of frameParts){const volume=overlap(ev(p.root),ev(f.root));if(volume>1e-5)motorFrameHits.push({motor:p.id,frame:f.id,volumeMm3:volume});}
check('Motor bodies clear the complete frame',motorFrameHits.length===0,motorFrameHits);
const fastenerHits=[];
for(const p of graph.parts.filter(p=>p.kind==='hardware'))for(const f of [...frameParts,...motorMounts]){const volume=overlap(ev(p.root),ev(f.root));if(volume>1e-5)fastenerHits.push({screw:p.id,part:f.id,volumeMm3:volume});}
check('Sixteen installed M2 screws fit plate and motor bores',fastenerHits.length===0&&graph.parts.filter(p=>p.kind==='hardware').length===16,fastenerHits);
const retentionHits=[];
for(const p of graph.parts.filter(p=>p.kind==='frame-hardware'||p.kind==='prop-hardware'))for(const q of graph.parts.filter(q=>q.kind==='frame'||q.kind==='motor'||q.kind==='prop')){const v=overlap(ev(p.root),ev(q.root));if(v>1e-5)retentionHits.push({fastener:p.id,part:q.id,volumeMm3:v});}
check('Plate and propeller retention hardware fits its bores',retentionHits.length===0,retentionHits);
const propMounts=graph.parts.filter(p=>p.kind==='prop').map((p,i)=>{
 const prop=ev(p.root),bell=ev(graph.parts.find(q=>q.id===`ava-v2-motor-${i+1}-bell`).root),pb=prop.boundingBox(),bb=bell.boundingBox();
 return {rotor:i+1,hubTop:32.45+2.45,bellSeat:bb.min[2],shaftEngagement:3,bodyOverlapMm3:overlap(prop,bell)};
});
check('Prop hubs seat on bells with 3 mm shaft engagement',propMounts.every(p=>Math.abs(p.hubTop-p.bellSeat)<1e-6&&p.bodyOverlapMm3<1e-5),propMounts);
const shell=graph.parts.filter(p=>/context-tv-(integrated-front-housing|rear-service-cover)$/.test(p.id));
const housingBottom=Math.min(...shell.map(p=>ev(p.root).boundingBox().min[2]));
check('Unchanged housing clears ducts',housingBottom>47,{housingBottom,ductTop:47,gap:housingBottom-47});
for(const p of frameParts.filter(p=>/heatset/.test(p.id))){const old=baseline.graph.parts.find(q=>q.id.startsWith('right-')&&p.id===`ava-v2-${q.id.replace(/^right-/,'')}`);const a=ev(p.root),b=ev(old.root).translate([-390,0,0]);check(`Exact retained geometry: ${old.id}`,Math.abs(a.volume()-b.volume())<1e-6&&overlap(a,b)>a.volume()-1e-5,{volumeMm3:a.volume()});b.delete();}
const payloadMountClearances=spec.adapterHoles.map(([x,y])=>{const gauge=M.cylinder(2,1,1,24,true).translate([x,y,48]);const hit=overlap(gauge,ev(spec.topPlateRoot));gauge.delete();return hit;});
check('Central payload mounting pattern and top plate Z retained',payloadMountClearances.every(v=>v<1e-5)&&ev(spec.topPlateRoot).boundingBox().min[2]===47&&ev(spec.topPlateRoot).boundingBox().max[2]===49,{pattern:spec.adapterHoles,intrusionsMm3:payloadMountClearances,z:[47,49]});
const structure=M.union(graph.parts.filter(p=>p.kind==='cradle'||p.id==='ava-v2-frame-plate'||/ava-v2-duct-/.test(p.id)).map(p=>ev(p.root)));
const bodies=structure.decompose();check('Frame, ducts and cradle form connected structure',bodies.length===1,{connectedBodies:bodies.length});bodies.forEach(s=>s.delete());structure.delete();

// Three additive live parts; component STL assets remain individually available.
const liveNodes=[],liveParts=[],liveGroups=graph.groups;
for(const [kind,kinds] of [['frame',['frame','hardware','frame-hardware']],['motors',['motor']],['cradle',['cradle']],['props',['prop','prop-hardware']],['battery',['battery']]]){
 const chosen=physical.filter(p=>kinds.includes(p.kind));
 let solid;
 if(kind==='motors'){
  // Live display uses representative external motor envelopes, retaining the
  // detailed bell/stator/mount/shaft exports above for the payload assembly.
  const motorSolids=spec.centres.map(([x,y])=>{
   const pieces=[M.cylinder(10.1,8.95,8.95,16,true).translate([x,y,39.95]),M.cylinder(1.5,8,8,16,true).translate([x,y,46.25]),M.cylinder(16.6,.75,.75,8,true).translate([x,y,40.2])];
   const motor=M.union(pieces);pieces.forEach(s=>s.delete());return motor;
  });
  solid=M.union(motorSolids);motorSolids.forEach(s=>s.delete());
 }else solid=M.union(chosen.map(p=>ev(p.root)));
 const cleaned=solid.simplify(.001),bytes=stl(cleaned);cleaned.delete();const mesh=parseSTL(new Uint8Array(bytes),'mm'),encoded=encodeMesh(mesh),hash=crypto.createHash('sha256').update(encoded).digest('hex');
 fs.writeFileSync(`${dir}/ava-v2-${kind}.stl`,bytes);fs.writeFileSync(`${dir}/assets/${hash}.bin`,encoded);
 liveNodes.push({id:`ava-v2-${kind}-mesh`,op:'mesh',inputs:[],params:[],mesh:hash,bounds:mesh.bounds},{id:`ava-v2-${kind}-placed`,op:'translate',inputs:[`ava-v2-${kind}-mesh`],params:spec.placement});
 liveParts.push({id:`ava-v2-${kind}`,root:`ava-v2-${kind}-placed`,color:chosen[0].color,group:'ava-v2'});solid.delete();
}
const liveGraph={schemaVersion:1,units:'mm',nodes:liveNodes,parts:liveParts,groups:liveGroups};
const proposed={...baseline.graph,nodes:[...baseline.graph.nodes,...liveNodes],parts:[...baseline.graph.parts,...liveParts],groups:[...baseline.graph.groups,...liveGroups]};
const liveTriangles=liveNodes.filter(n=>n.op==='mesh').reduce((s,n)=>s+decodeMesh(new Uint8Array(fs.readFileSync(`${dir}/assets/${n.mesh}.bin`))).indices.length/3,0);
let originalTriangles=0;for(const p of baseline.graph.parts)originalTriangles+=ev(p.root).numTri();
const budget={oldParts:baseline.graph.parts.length,newParts:liveParts.length,totalParts:proposed.parts.length,totalNodes:proposed.nodes.length,graphBytes:Buffer.byteLength(JSON.stringify(proposed)),oldRenderTriangles:originalTriangles,newRenderTriangles:liveTriangles,totalRenderBytes:(originalTriangles+liveTriangles)*108,renderLimitBytes:12*1024*1024};
const liveReady=budget.totalParts<=256&&budget.totalNodes<=8192&&budget.graphBytes<=2*1024*1024&&budget.totalRenderBytes<=budget.renderLimitBytes;
check('Existing graph unchanged in proposed scene',['nodes','parts','groups'].every(k=>JSON.stringify(proposed[k].slice(0,baseline.graph[k].length))===JSON.stringify(baseline.graph[k])),{baselineRevision:baseline.revision});
// Export distinct fabrication prototypes and purchased-part reference meshes.
fs.mkdirSync(`${dir}/fabrication`,{recursive:true});
const carrier=M.union(graph.parts.filter(p=>p.kind==='cradle'||p.id==='ava-v2-frame-plate'||/ava-v2-duct-/.test(p.id)).map(p=>ev(p.root)));
fs.writeFileSync(`${dir}/fabrication/guard-carrier-and-battery-saddle-prototype.stl`,stl(carrier));carrier.delete();
fs.writeFileSync(`${dir}/fabrication/upper-plate-2mm-carbon-reference.stl`,stl(ev(spec.topPlateRoot)));
const section=ev(spec.topPlateRoot).slice(48),contours=section.toPolygons();section.delete();
let dxf='0\nSECTION\n2\nHEADER\n9\n$INSUNITS\n70\n4\n0\nENDSEC\n0\nSECTION\n2\nENTITIES\n';
for(const contour of contours){dxf+=`0\nLWPOLYLINE\n8\nCUT\n90\n${contour.length}\n70\n1\n`;for(const [x,y]of contour)dxf+=`10\n${x}\n20\n${y}\n`;}
fs.writeFileSync(`${dir}/fabrication/upper-plate-2mm-carbon-prototype.dxf`,dxf+'0\nENDSEC\n0\nEOF\n');
const assembledSolid=M.union(graph.parts.map(p=>ev(p.root)));fs.writeFileSync(`${dir}/ava-v2-assembly.stl`,stl(assembledSolid));assembledSolid.delete();
const volume=kind=>measurements.filter(p=>kind(p)).reduce((a,p)=>a+p.volumeMm3,0);
const carrierVolume=volume(p=>p.kind==='cradle'||p.id==='ava-v2-frame-plate'||/ava-v2-duct-/.test(p.id));
const carbonVolume=measurements.find(p=>p.id==='ava-v2-upper-motor-plate-3inch').volumeMm3;
const mass={payload:275,motors:4*9.34,props:4*1.48,battery:141,carrierPA12:carrierVolume*.00101,carbonPlate:carbonVolume*.00155,hardwarePadStrapsWiringAllowance:15};
const estimatedMassG=Object.values(mass).reduce((a,b)=>a+b,0),benchThrustG=4*310.57;
const massBudget={basis:'User supplied 275 g payload including housing; manufacturer component masses; solid CAD carrier volume at assumed PA12 density1.01g/cm3, carbon1.55g/cm3; 15g installation allowance. Not measured.',componentsG:mass,estimatedMassG,benchThrustG,idealBenchThrustToWeight:benchThrustG/estimatedMassG,target:3.8,targetMet:benchThrustG/estimatedMassG>=3.8,peakMotorCurrentA:20.23,quadPeakMotorCurrentA:80.92,note:'Open bench thrust, without housing/guards or battery sag. Actual thrust-to-weight will differ. 35A ESC must mean per channel; power distribution and connector temperatures require testing.'};
fs.writeFileSync(`${dir}/mass-budget.json`,JSON.stringify(massBudget,null,2));
const oldPreview=JSON.parse(fs.readFileSync('themis-output/preview-geometry.json'));
fs.writeFileSync(`${dir}/preview-geometry.json`,JSON.stringify([...oldPreview,...preview]));
const atlasSolids=physical.map((p,i)=>ev(p.root).translate([(i%6)*220,Math.floor(i/6)*220,0]));
const packed=M.compose(atlasSolids),packedBytes=stl(packed),packedMesh=parseSTL(new Uint8Array(packedBytes),'mm'),packedAsset=encodeMesh(packedMesh),packedHash=crypto.createHash('sha256').update(packedAsset).digest('hex');
fs.writeFileSync(`${dir}/atlas.stl`,packedBytes);fs.writeFileSync(`${dir}/assets/${packedHash}.bin`,packedAsset);packed.delete();atlasSolids.forEach(s=>s.delete());
fs.writeFileSync(`${dir}/atlas.json`,JSON.stringify({units:'mm',coordinateSystem:'Part meshes use local v2 centre at x=0,y=0; original Z retained; live translation [650,0,0]',mesh:packedHash,stl:'atlas.stl',bounds:packedMesh.bounds,parts:atlas.map((p,i)=>({...p,atlasOffset:[(i%6)*220,Math.floor(i/6)*220,0]}))},null,2));
fs.writeFileSync(`${dir}/live-addition.json`,JSON.stringify(liveGraph,null,2));
fs.writeFileSync(`${dir}/proposed-scene.json`,JSON.stringify({revision:baseline.revision,status:'LOCAL PROPOSAL, NOT SAVED TO DINGCAD',graph:proposed}));
fs.writeFileSync(`${dir}/part-measurements.json`,JSON.stringify(measurements,null,2));
const result={revision:'ava-v2-refined-20260919',flightReady:false,releaseStatus:'Geometry-checked prototype; propulsion target unmet; hardware and flight qualification pending',massBudget,passed:checks.every(c=>c.pass),status:'exported-prototype',liveReady,liveRepresentation:'Five grouped parts, with 16-sided external motor envelopes; detailed motor components remain in atlas and individual STLs. Live mesh simplification tolerance 0.001 mm.',liveBlockers:liveReady?[]:['The additive scene exceeds the 12 MiB render budget; do not upload this proposal unchanged.'],assemblyDimensions:assembled.size,checks,budget};
fs.writeFileSync(`${dir}/validation.json`,JSON.stringify(result,null,2));
console.log(JSON.stringify(result,null,2));
for(const s of cache.values())s.delete();
assert(result.passed,'V2 validation failed; see validation.json');
