import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import Module from 'manifold-3d';
import {decodeMesh,encodeMesh,parseSTL} from './vendor/dingcad/mesh-import.mjs';
const dir='themis-output/v2';
const graph=JSON.parse(fs.readFileSync(`${dir}/design-graph.json`));
const spec=JSON.parse(fs.readFileSync(`${dir}/design-spec.json`));
const baselineBytes=fs.readFileSync('themis-output/live-scene.json');
assert.equal(crypto.createHash('sha256').update(baselineBytes).digest('hex'),spec.baselineSha256,'Saved baseline changed');
const baseline=JSON.parse(baselineBytes);
const kernel=await Module();kernel.setup();const M=kernel.Manifold;
const source=new Map([...baseline.graph.nodes,...graph.nodes].map(n=>[n.id,n])),cache=new Map(),materials=new Map();
function ev(id){
 if(cache.has(id))return cache.get(id);
 const n=source.get(id);assert(n,`Missing ${id}`);const input=n.inputs.map(ev),p=n.params;let s;
 switch(n.op){
 case 'box':s=M.cube(p,true);break;
 case 'cylinder':s=M.cylinder(p[0],p[1],p[1],n.segments??32,true);break;
 case 'cone':s=M.cylinder(p[0],p[1],p[2],n.segments??32,true);break;
 case 'sphere':s=M.sphere(p[0],n.segments??32);break;
 case 'translate':s=input[0].translate(p);break;
 case 'rotate':s=input[0].rotate(p);break;
 case 'scale':s=input[0].scale(p);break;
 case 'union':s=input[0].add(input[1]);break;
 case 'difference':s=input[0].subtract(input[1]);break;
 case 'intersection':s=input[0].intersect(input[1]);break;
 case 'hull':s=M.hull(input);break;
 case 'extrude':{const cs=new kernel.CrossSection(n.profile,'EvenOdd');s=cs.extrude(p[0],0,0,[1,1],true);cs.delete();break;}
 case 'mesh':{const m=decodeMesh(new Uint8Array(fs.readFileSync(`themis-output/assets/${n.mesh}.bin`)));s=new M(new kernel.Mesh({numProp:3,vertProperties:m.vertices,triVerts:m.indices}));break;}
 default:throw Error(`Unsupported ${n.op}`);
 }
 assert.equal(s.status(),'NoError',id);
 let mat=new Map();for(const k of n.inputs)for(const [key,c]of materials.get(k)||[])mat.set(key,c);
 if(n.color){const colored=s.asOriginal();s.delete();s=colored;mat=new Map([[s.originalID(),n.color]]);}
 cache.set(id,s);materials.set(id,mat);return s;
}
function overlap(a,b){const c=a.intersect(b),v=c.volume();c.delete();return v;}
function bounds(solids){const b={min:[Infinity,Infinity,Infinity],max:[-Infinity,-Infinity,-Infinity]};for(const s of solids){const q=s.boundingBox();for(let k=0;k<3;k++){b.min[k]=Math.min(b.min[k],q.min[k]);b.max[k]=Math.max(b.max[k],q.max[k]);}}return {...b,size:b.max.map((x,k)=>x-b.min[k])};}
function stl(s){const clean=s.simplify(.001),m=clean.getMesh();const b=Buffer.alloc(84+50*m.numTri);b.write('AVA v2 concept; mm; export simplification tolerance 0.001 mm');b.writeUInt32LE(m.numTri,80);for(let t=0;t<m.numTri;t++)for(let j=0;j<3;j++)for(let k=0;k<3;k++)b.writeFloatLE(m.vertProperties[m.triVerts[t*3+j]*m.numProp+k],84+50*t+12+12*j+4*k);clean.delete();return b;}
fs.mkdirSync(`${dir}/assets`,{recursive:true});fs.mkdirSync(`${dir}/parts`,{recursive:true});
const atlas=[],preview=[],measurements=[];
for(const p of graph.parts){
 const s=ev(p.root);assert(s.numTri()>0,p.id);const b=s.boundingBox();measurements.push({id:p.id,kind:p.kind,bounds:b,triangles:s.numTri(),volumeMm3:s.volume()});
 if(p.kind!=='context'){
  const bytes=stl(s);let mesh;try{mesh=parseSTL(new Uint8Array(bytes),'mm');}catch(e){fs.writeFileSync('/tmp/ava-v2-failed.stl',bytes);throw Error(`${p.id}: ${e.message}`);}const encoded=encodeMesh(mesh),hash=crypto.createHash('sha256').update(encoded).digest('hex');
  fs.writeFileSync(`${dir}/parts/${p.id}.stl`,bytes);fs.writeFileSync(`${dir}/assets/${hash}.bin`,encoded);
  atlas.push({id:p.id,kind:p.kind,color:p.color,mesh:hash,stl:`parts/${p.id}.stl`,bounds:mesh.bounds,triangles:mesh.triangles});
 }
 const m=s.getMesh(),colors=[];let run=0;const mat=materials.get(p.root);
 for(let t=0;t<m.triVerts.length;t+=3){while(run+1<m.runOriginalID.length&&t>=m.runIndex[run+1])run++;colors.push(...(mat.get(m.runOriginalID[run])||p.color));}
 preview.push({id:p.id,color:p.color,group:p.kind==='context'?'v2-payload-context':`v2-${p.kind}`,positions:Array.from(m.vertProperties, (x,i)=>x+(i%3===0?650:0)),indices:Array.from(m.triVerts),faceColors:colors});
}
const checks=[];
const check=(name,pass,details)=>checks.push({name,pass,details});
const physical=graph.parts.filter(p=>p.kind!=='context');
const frameParts=graph.parts.filter(p=>p.kind==='frame');
const dims=bounds(physical.map(p=>ev(p.root)));
check('166 mm frame footprint',dims.size[0]===166&&dims.size[1]===166,dims);
const assembled=bounds(graph.parts.map(p=>ev(p.root)));
check('Individual assembled v2 fits 250 mm cube',assembled.size.every(x=>x<=250),assembled);
check('Duct spacing',spec.centres[1][0]-spec.centres[0][0]===83,{spacing:83,outerDiameter:82,gap:1});
let ductOverlap=0;for(let i=0;i<4;i++)for(let j=i+1;j<4;j++)ductOverlap+=overlap(ev(spec.ductRoots[i]),ev(spec.ductRoots[j]));
check('Adjacent ducts do not intersect',ductOverlap<1e-6,{intersectionMm3:ductOverlap});
const rotorHits=[];
for(let i=0;i<4;i++)for(const p of graph.parts){const v=overlap(ev(spec.sweeps[i]),ev(p.root));if(v>1e-5)rotorHits.push({rotor:i+1,part:p.id,volumeMm3:v});}
check('3-inch swept volumes clear all geometry',rotorHits.length===0,rotorHits);
check('Minimum duct ID and prop clearance',79>=76.2+2,{minimumDuctId:79,propDiameter:76.2,diametralClearance:2.8,radialClearance:1.4});
const batteryHits=physical.map(p=>({part:p.id,volumeMm3:overlap(ev(spec.battery),ev(p.root))})).filter(p=>p.volumeMm3>1e-5);
check('Battery clears cradle and frame',batteryHits.length===0,batteryHits);
const marginEnvelope=M.cube([74,42,29],true).translate([0,0,4.5]);
const marginIntrusion=physical.reduce((v,p)=>v+overlap(marginEnvelope,ev(p.root)),0);marginEnvelope.delete();
check('Battery cavity margins at least 2 mm',marginIntrusion<1e-5,{expandedEnvelopeIntrusionMm3:marginIntrusion,xPerSide:2.5,yPerSide:2,zBelow:2,zAbove:3,internal:[75,42,30],externalTray:[79,46,32]});
const motorMounts=graph.parts.filter(p=>/^ava-v2-motor-\d-mount$/.test(p.id));
const mountIntrusions=spec.mountHoles.map(([x,y],i)=>{const gauge=M.cylinder(4,1,1,32,true).translate([x,y,47.25]);const volume=overlap(gauge,ev(spec.topPlateRoot))+overlap(gauge,ev(motorMounts[Math.floor(i/4)].root));gauge.delete();return volume;});
check('All sixteen M2 holes align through motor bases and upper plate',mountIntrusions.every(v=>v<1e-5),{pitchCircleDiameter:9,holesPerMotor:4,intrusionMm3:mountIntrusions});
const seating= motorMounts.map((p,i)=>{
 const motor=ev(p.root),plate=ev(spec.topPlateRoot).translate([0,0,-.1]),contact=overlap(motor,plate);plate.delete();
 const shaft=ev(graph.parts.find(p=>p.id===`ava-v2-motor-${i+1}-shaft`).root).boundingBox();
 const centre=shaft.min.slice(0,2).map((x,k)=>(x+shaft.max[k])/2);
 return {motor:i+1,centre,mountFaceZ:motor.boundingBox().max[2],supportedFraction:contact/(motor.volume()/1.5*.1),centreErrorMm:Math.hypot(...centre.map((x,k)=>x-spec.centres[i][k]))};
});
check('All motors centred and fully seated at z47',seating.every(s=>s.centreErrorMm<1e-6&&s.mountFaceZ===47&&s.supportedFraction>.999),seating);
const motorFrameHits=[];
for(const p of graph.parts.filter(p=>p.kind==='motor'))for(const f of frameParts){const volume=overlap(ev(p.root),ev(f.root));if(volume>1e-5)motorFrameHits.push({motor:p.id,frame:f.id,volumeMm3:volume});}
check('Motor bodies clear the complete frame',motorFrameHits.length===0,motorFrameHits);
const fastenerHits=[];
for(const p of graph.parts.filter(p=>p.kind==='hardware'))for(const f of [...frameParts,...motorMounts]){const volume=overlap(ev(p.root),ev(f.root));if(volume>1e-5)fastenerHits.push({screw:p.id,part:f.id,volumeMm3:volume});}
check('Sixteen installed M2 screws fit plate and motor bores',fastenerHits.length===0&&graph.parts.filter(p=>p.kind==='hardware').length===16,fastenerHits);
const shell=graph.parts.filter(p=>/context-tv-(integrated-front-housing|rear-service-cover)$/.test(p.id));
const housingBottom=Math.min(...shell.map(p=>ev(p.root).boundingBox().min[2]));
check('Unchanged housing clears ducts',housingBottom>47,{housingBottom,ductTop:47,gap:housingBottom-47});
for(const p of frameParts.filter(p=>/heatset/.test(p.id))){const old=baseline.graph.parts.find(q=>q.id.startsWith('right-')&&p.id===`ava-v2-${q.id.replace(/^right-/,'')}`);const a=ev(p.root),b=ev(old.root).translate([-390,0,0]);check(`Exact retained geometry: ${old.id}`,Math.abs(a.volume()-b.volume())<1e-6&&overlap(a,b)>a.volume()-1e-5,{volumeMm3:a.volume()});b.delete();}
const payloadMountClearances=spec.adapterHoles.map(([x,y])=>{const gauge=M.cylinder(2,1,1,24,true).translate([x,y,48]);const hit=overlap(gauge,ev(spec.topPlateRoot));gauge.delete();return hit;});
check('Central payload mounting pattern and top plate Z retained',payloadMountClearances.every(v=>v<1e-5)&&ev(spec.topPlateRoot).boundingBox().min[2]===47&&ev(spec.topPlateRoot).boundingBox().max[2]===49,{pattern:spec.adapterHoles,intrusionsMm3:payloadMountClearances,z:[47,49]});
const structure=M.union(graph.parts.filter(p=>p.kind==='cradle'||p.id==='ava-v2-frame-plate'||/ava-v2-duct-/.test(p.id)).map(p=>ev(p.root)));
const bodies=structure.decompose();check('Frame, ducts and cradle form connected structure',bodies.length===1,{connectedBodies:bodies.length});bodies.forEach(s=>s.delete());structure.delete();

// Three additive live parts; component STL assets remain individually available.
const liveNodes=[],liveParts=[],liveGroups=graph.groups;
for(const [kind,kinds] of [['frame',['frame','hardware']],['motors',['motor']],['cradle',['cradle']]]){
 const chosen=physical.filter(p=>kinds.includes(p.kind));
 let solid;
 if(kind==='motors'){
  // Live display uses representative external motor envelopes, retaining the
  // detailed bell/stator/mount/shaft exports above for the payload assembly.
  const motorSolids=spec.centres.map(([x,y])=>{
   const pieces=[M.cylinder(13.5,9.95,9.95,16,true).translate([x,y,38.75]),M.cylinder(1.5,8,8,16,true).translate([x,y,46.25]),M.cylinder(2,.75,.75,8,true).translate([x,y,31])];
   const motor=M.union(pieces);pieces.forEach(s=>s.delete());return motor;
  });
  solid=M.union(motorSolids);motorSolids.forEach(s=>s.delete());
 }else solid=M.union(chosen.map(p=>ev(p.root)));
 const cleaned=solid.simplify(.001),bytes=stl(cleaned);cleaned.delete();const mesh=parseSTL(new Uint8Array(bytes),'mm'),encoded=encodeMesh(mesh),hash=crypto.createHash('sha256').update(encoded).digest('hex');
 fs.writeFileSync(`${dir}/ava-v2-${kind}.stl`,bytes);fs.writeFileSync(`${dir}/assets/${hash}.bin`,encoded);
 liveNodes.push({id:`ava-v2-${kind}-mesh`,op:'mesh',inputs:[],params:[],mesh:hash,bounds:mesh.bounds},{id:`ava-v2-${kind}-placed`,op:'translate',inputs:[`ava-v2-${kind}-mesh`],params:spec.placement});
 liveParts.push({id:`ava-v2-${kind}`,root:`ava-v2-${kind}-placed`,color:chosen[0].color,group:'ava-v2'});solid.delete();
}
const liveGraph={schemaVersion:1,units:'mm',nodes:liveNodes,parts:liveParts,groups:liveGroups};
const proposed={...baseline.graph,nodes:[...baseline.graph.nodes,...liveNodes],parts:[...baseline.graph.parts,...liveParts],groups:[...baseline.graph.groups,...liveGroups]};
const liveTriangles=liveNodes.filter(n=>n.op==='mesh').reduce((s,n)=>s+decodeMesh(new Uint8Array(fs.readFileSync(`${dir}/assets/${n.mesh}.bin`))).indices.length/3,0);
let originalTriangles=0;for(const p of baseline.graph.parts)originalTriangles+=ev(p.root).numTri();
const budget={oldParts:baseline.graph.parts.length,newParts:liveParts.length,totalParts:proposed.parts.length,totalNodes:proposed.nodes.length,graphBytes:Buffer.byteLength(JSON.stringify(proposed)),oldRenderTriangles:originalTriangles,newRenderTriangles:liveTriangles,totalRenderBytes:(originalTriangles+liveTriangles)*108,renderLimitBytes:12*1024*1024};
const liveReady=budget.totalParts<=256&&budget.totalNodes<=8192&&budget.graphBytes<=2*1024*1024&&budget.totalRenderBytes<=budget.renderLimitBytes;
check('Existing graph unchanged in proposed scene',['nodes','parts','groups'].every(k=>JSON.stringify(proposed[k].slice(0,baseline.graph[k].length))===JSON.stringify(baseline.graph[k])),{baselineRevision:baseline.revision});
const oldPreview=JSON.parse(fs.readFileSync('themis-output/preview-geometry.json'));
fs.writeFileSync(`${dir}/preview-geometry.json`,JSON.stringify([...oldPreview,...preview]));
const atlasSolids=physical.map((p,i)=>ev(p.root).translate([(i%6)*220,Math.floor(i/6)*220,0]));
const packed=M.compose(atlasSolids),packedBytes=stl(packed),packedMesh=parseSTL(new Uint8Array(packedBytes),'mm'),packedAsset=encodeMesh(packedMesh),packedHash=crypto.createHash('sha256').update(packedAsset).digest('hex');
fs.writeFileSync(`${dir}/atlas.stl`,packedBytes);fs.writeFileSync(`${dir}/assets/${packedHash}.bin`,packedAsset);packed.delete();atlasSolids.forEach(s=>s.delete());
fs.writeFileSync(`${dir}/atlas.json`,JSON.stringify({units:'mm',coordinateSystem:'Part meshes use local v2 centre at x=0,y=0; original Z retained; live translation [650,0,0]',mesh:packedHash,stl:'atlas.stl',bounds:packedMesh.bounds,parts:atlas.map((p,i)=>({...p,atlasOffset:[(i%6)*220,Math.floor(i/6)*220,0]}))},null,2));
fs.writeFileSync(`${dir}/live-addition.json`,JSON.stringify(liveGraph,null,2));
fs.writeFileSync(`${dir}/proposed-scene.json`,JSON.stringify({revision:baseline.revision,status:'LOCAL PROPOSAL, NOT SAVED TO DINGCAD',graph:proposed}));
fs.writeFileSync(`${dir}/part-measurements.json`,JSON.stringify(measurements,null,2));
const result={passed:checks.every(c=>c.pass),status:'local-only',liveReady,liveRepresentation:'Three grouped parts, with 16-sided external motor envelopes; detailed motor components remain in atlas and individual STLs. Live mesh simplification tolerance 0.001 mm.',liveBlockers:liveReady?[]:['The additive scene exceeds the 12 MiB render budget; do not upload this proposal unchanged.'],assemblyDimensions:assembled.size,checks,budget};
fs.writeFileSync(`${dir}/validation.json`,JSON.stringify(result,null,2));
console.log(JSON.stringify(result,null,2));
for(const s of cache.values())s.delete();
assert(result.passed,'V2 validation failed; see validation.json');
