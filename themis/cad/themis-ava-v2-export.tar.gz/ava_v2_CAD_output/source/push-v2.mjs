import fs from 'node:fs';
import assert from 'node:assert/strict';

// Additive only. Credentials are read from the environment and never persisted.
const token=process.env.DINGCAD_TOKEN;
if(!token)throw Error('Supply a fresh Dingcad connection token in DINGCAD_TOKEN');
const dir='themis-output/v2',origin='https://dingcad.com';
const validation=JSON.parse(fs.readFileSync(`${dir}/validation.json`));
assert(validation.passed&&validation.liveReady,'Rebuild and validate the v2 proposal before uploading');
const baseline=JSON.parse(fs.readFileSync('themis-output/live-scene.json'));
const addition=JSON.parse(fs.readFileSync(`${dir}/live-addition.json`));
async function publicText(path){const r=await fetch(origin+path);if(!r.ok)throw Error(`Documentation HTTP ${r.status}`);return r.text();}
const protocol=JSON.parse(await publicText('/api/cad/protocol'));
assert.equal(protocol.protocolVersion,3,'Protocol changed; review current instructions');
await publicText('/live-api.txt');await publicText('/live-manifold.txt');await publicText('/live-operations.json');
const sdk=await publicText('/live-sdk.mjs');
const {Dingcad}=await import('data:text/javascript;base64,'+Buffer.from(sdk).toString('base64'));
const cad=new Dingcad({origin,token});
const journalPath=`${dir}/additive-commit-journal.json`;
let journal=fs.existsSync(journalPath)?JSON.parse(fs.readFileSync(journalPath)):null;
const persist=()=>fs.writeFileSync(journalPath,JSON.stringify(journal,null,2));
function assertOldIntact(graph){for(const key of ['nodes','parts','groups']){const current=new Map(graph[key].map(x=>[x.id,x]));for(const old of baseline.graph[key])assert.deepEqual(current.get(old.id),old,`Existing ${key} changed: ${old.id}`);}}
const live=await cad.read();assert.equal(live.id,baseline.id,'Connection points to a different document');assertOldIntact(live.graph);
if(!journal){
 assert.deepEqual(live.graph,baseline.graph,'Live document changed; rebase and revalidate the additive proposal');
 fs.writeFileSync(`${dir}/live-before.json`,JSON.stringify(live));
 const uploaded={};
 for(const kind of ['frame','motors','cradle']){
  const asset=await cad.uploadSTL(fs.readFileSync(`${dir}/ava-v2-${kind}.stl`),{units:'mm'});
  const n=addition.nodes.find(n=>n.id===`ava-v2-${kind}-mesh`);uploaded[n.mesh]=asset;
 }
 const commands=addition.groups.map(group=>({op:'putGroup',group}));
 for(const n of addition.nodes){const node=n.op==='mesh'?{...n,mesh:uploaded[n.mesh].mesh,bounds:uploaded[n.mesh].bounds}:n;commands.push({op:'putNode',node});}
 commands.push(...addition.parts.map(part=>({op:'putPart',part})));
 journal={baselineRevision:live.revision,revision:live.revision,index:0,pending:null,commands};persist();
}
let lastCheck=Date.now();
while(journal.index<journal.commands.length){
 if(Date.now()-lastCheck>300000){const next=JSON.parse(await publicText('/api/cad/protocol'));assert.deepEqual(next,protocol,'Protocol changed; exact pending request retained');lastCheck=Date.now();}
 journal.pending??=cad.commitRequest(journal.revision,[journal.commands[journal.index]]);persist();
 // On failure retain this exact request, including its UUID, for safe resumption.
 const saved=await cad.commit(journal.pending);
 journal.revision=saved.revision;journal.index++;journal.pending=null;persist();
 console.log({savedRevision:journal.revision,completed:journal.index,total:journal.commands.length});
}
const saved=await cad.read();assertOldIntact(saved.graph);
for(const command of journal.commands){const key={putGroup:'groups',putNode:'nodes',putPart:'parts'}[command.op],value=command.group||command.node||command.part;assert.deepEqual(saved.graph[key].find(x=>x.id===value.id),value,`Saved addition mismatch: ${value.id}`);}
fs.writeFileSync(`${dir}/live-saved.json`,JSON.stringify(saved));
fs.writeFileSync(`${dir}/live-viewers.json`,JSON.stringify(await cad.viewers(),null,2));
console.log({savedRevision:saved.revision,oldDesignPreserved:true,viewers:'Separate browser observations saved in live-viewers.json'});
