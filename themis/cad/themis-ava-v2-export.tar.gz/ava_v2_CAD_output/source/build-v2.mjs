import fs from 'node:fs';
import crypto from 'node:crypto';

// Additive variant only. Never run the historical replacement generators here.
const out = 'themis-output/v2';
fs.mkdirSync(out, {recursive:true});
const baselineBytes = fs.readFileSync('themis-output/live-scene.json');
const baseline = JSON.parse(baselineBytes);
const nodes=[], parts=[], groups=[{id:'ava-v2',name:'AVA v2 · 3-inch / 1404 · new comparison design'}];
let serial=0;
const C={prop:[.8,.22,.025],battery:[.06,.07,.08],frame:[.035,.045,.055],orange:[.8,.22,.025],metal:[.22,.26,.30],black:[.008,.011,.016],copper:[.45,.16,.05]};
const add=(op,params=[],inputs=[],extra={})=>{const id=`ava-v2-n${++serial}`;nodes.push({id,op,params,inputs,...extra});return id;};
const move=(s,p)=>add('translate',p,[s]);
const box=(d,p)=>move(add('box',d),p);
const cyl=(r,h,p,segments=32)=>move(add('cylinder',[h,r],[],{segments}),p);
function combine(a,op='union'){if(a.length===1)return a[0];const k=a.length>>1;return add(op,[],[combine(a.slice(0,k),op),combine(a.slice(k),op)]);}
const diff=(a,b)=>add('difference',[],[a,b]);
const hull=a=>add('hull',[],a);
const roundedBox=(d,p,r=2)=>hull([-1,1].flatMap(x=>[-1,1].map(y=>cyl(r,d[2],[p[0]+x*(d[0]/2-r),p[1]+y*(d[1]/2-r),p[2]],16))));
const ring=(ro,ri,h,p,n=32)=>diff(cyl(ro,h,p,n),cyl(ri,h+2,p,n));
const emit=(id,root,color,kind)=>{const p={id:`ava-v2-${id}`,root,color,group:'ava-v2',kind};parts.push(p);return p;};
const source=new Map(baseline.graph.nodes.map(n=>[n.id,n])),memo=new Map();
function clone(id){if(memo.has(id))return memo.get(id);const n=source.get(id);const root=add(n.op,n.params,n.inputs.map(clone),Object.fromEntries(Object.entries(n).filter(([k])=>!['id','op','params','inputs'].includes(k))));memo.set(id,root);return root;}
const centres=[[-41.5,-41.5],[41.5,-41.5],[-41.5,41.5],[41.5,41.5]];
const mountHoles=centres.flatMap(([x,y])=>[[x+4.5,y],[x,y+4.5],[x-4.5,y],[x,y-4.5]]);
const adapterHoles=[[-13,-22.8],[-13,22.8],[13,-22.8],[13,22.8]];
const frameHoles=[[0,-18.03125],[18.03125,0],[0,18.03125],[-18.03125,0]];
const bores=xy=>combine(xy.map(([x,y])=>cyl(1.1,30,[x,y,45],8)));
// One mount definition drives the frame boss, carbon landing, insert, spacer
// and screw. Keep the housing's 26 x45.6 pattern and z52 floor datum.
const payloadMounts=adapterHoles.map(([x,y],i)=>{
 const oldId=`right-frame-M2x3-heatset-${i+1}`;
 const oldPart=baseline.graph.parts.find(p=>p.id===oldId);
 const oldCentre=source.get(`${oldId}-position`).params;
 const insertCentre=[x,y,45];
 const insertOffset=insertCentre.map((v,k)=>v-oldCentre[k]);
 const insertRoot=move(clone(oldPart.root),insertOffset);
 const index=(y>0?2:0)+(x>0?2:1);
 return {centre:[x,y],index,bossRadius:4.5,bossBottomZ:42,insertCentre,
  insertRoot,insertOffset,oldInsertId:oldId,insertId:`ava-v2-frame-M2x3-heatset-${i+1}`,
  spacerId:`ava-v2-context-tv-adapter-spacer-${index}`,
  screwId:`ava-v2-context-tv-adapter-M2-screw-${index}`,
  screwLength:12,screwTipZ:43,headSeatZ:55};
});

// Duct bores are circumscribed polygons: their minimum clear ID is 79 mm.
// Small outer datum bumpers bring the otherwise 165 mm duct envelope to 166 mm.
const ducts=centres.map(([x,y],i)=>{
 const tube=ring(41,39.5/Math.cos(Math.PI/96),10,[x,y,32],96);
 // Inner-quadrant riser transfers guard loads into the central carrier,
 // entirely outside the swept disc until above the blade envelope.
 const px=x-Math.sign(x)*28.4,py=y-Math.sign(y)*28.4;
 const riser=diff(cyl(3,10,[px,py,42],24),cyl(39.5/Math.cos(Math.PI/96),30,[x,y,34],96));
 return emit(`duct-${i+1}`,combine([tube,riser,box([1,4,2],[Math.sign(x)*82.5,y,30]),box([4,1,2],[x,Math.sign(y)*82.5,30])]),C.frame,'frame');
});
const beams=[roundedBox([46,50,2],[0,0,46],8)];
for(const [x,y] of frameHoles)beams.push(cyl(3.8,10,[x,y,40],16));
for(const m of payloadMounts)beams.push(cyl(m.bossRadius,5,[...m.centre,44.5],48));
// Installed-insert envelopes: the build guide distinguishes these from the
// supplier-specific heat-setting pilot holes required before fabrication.
const insertPockets=payloadMounts.map(m=>hull([m.insertRoot,move(m.insertRoot,[0,0,1])]));
const frame=emit('frame-plate',diff(combine(beams),combine([bores([...adapterHoles,...frameHoles]),...insertPockets])),C.frame,'frame');

// GNB11004S140A purchased pack: 82 x 39 x 25 mm, 141 +/-4 g.
// Open 86 x 43 saddle; 2 mm side/end clearance, 2 mm compliant pad.
// Only the shallow floor and locating lips surround the battery.
const floor=roundedBox([90,47,2],[0,0,-8.5],5);
const slots=combine([-24,24].flatMap(x=>[-21.5,21.5].map(y=>box([12,2,4],[x,y,-8.5]))));
const lips=diff(roundedBox([90,47,5],[0,0,-5],5),roundedBox([86,43,7],[0,0,-5],3));
const rails=[-23,23].map(y=>roundedBox([7,3,52.5],[0,y,18.25],1));
emit('battery-cradle',combine([diff(floor,slots),lips,...rails]),C.frame,'cradle');
const battery=roundedBox([82,39,25],[0,0,7],2);
emit('battery-GNB11004S140A-1100mAh-4S',battery,C.battery,'battery');
emit('battery-2mm-foam-pad',box([80,38,2],[0,0,-6.5]),C.black,'battery');
for(const x of [-24,24]){
 // Closed retention loop, threaded through the two saddle slots.
 const strap=move(add('rotate',[90,0,90],[add('extrude',[10],[],{profile:[[[-22.25,-10.3],[22.25,-10.3],[22.25,-7],[20.3,20.3],[-20.3,20.3],[-22.25,-7]],[[-21.45,-9.5],[21.45,-9.5],[21.45,-7],[19.5,19.5],[-19.5,19.5],[-21.45,-7]]]})]),[x,0,0]);
 emit(`battery-strap-${x<0?1:2}`,strap,C.orange,'battery');
}
for(let i=0;i<4;i++){
 const [x,y]=centres[i];
 // Inverted motor seats against the upper plate at the original z47 datum.
 // T-Motor F1404: diameter 17.9, overall 16.6, exposed 1.5 shaft x3.
 // Rear bearing protrudes through the plate relief; surfaces between published
 // dimensions are representative. Mount face remains z47.
 const propBores=combine([-2.5,2.5].map(dx=>cyl(1.05,4,[x+dx,y,35],16)));
 const bell=diff(combine([ring(8.95,7.6,10.1,[x,y,39.95],48),cyl(8.95,2.2,[x,y,36],48)]),propBores);
 emit(`motor-${i+1}-bell`,bell,C.black,'motor');
 emit(`motor-${i+1}-stator`,cyl(7,4,[x,y,41],24),C.copper,'motor');
 emit(`motor-${i+1}-mount`,diff(ring(8,2.7,1.5,[x,y,46.25],32),bores(mountHoles.slice(i*4,i*4+4))),C.metal,'motor');
 emit(`motor-${i+1}-shaft`,combine([cyl(.75,15.1,[x,y,39.45],16),cyl(2.5,1.5,[x,y,47.75],24)]),C.metal,'motor');
 for(let j=0;j<4;j++){
  const [hx,hy]=mountHoles[i*4+j];
  emit(`motor-${i+1}-M2-screw-${j+1}`,combine([cyl(1,4,[hx,hy,47],12),diff(cyl(1.8,1.4,[hx,hy,49.7],12),cyl(.8,.7,[hx,hy,50.15],6))]),C.metal,'hardware');
 }
}

// Removable upper carbon plate: M2x16 screws with M2 nuts below the posts.
for(let i=0;i<frameHoles.length;i++){
 const [x,y]=frameHoles[i];
 emit(`frame-M2x16-screw-${i+1}`,combine([cyl(1,16,[x,y,41],16),diff(cyl(1.8,1.4,[x,y,49.7],16),cyl(.8,.7,[x,y,50.15],6))]),C.metal,'frame-hardware');
 emit(`frame-M2-nut-${i+1}`,ring(2.31,1.1,1.6,[x,y,34.2],6),C.metal,'frame-hardware');
}

// Retain the central plate interface, but remove all obsolete 1104 motor tabs.
// New load-bearing arms and sixteen holes share the motor/duct centre definitions.
const originalTop=baseline.graph.parts.find(p=>p.id==='right-pavo2-carbon-top-plate-reference');
const centrePlate=add('intersection',[],[move(clone(originalTop.root),[-390,0,0]),box([46,50,4],[0,0,48])]);
const upper=[centrePlate,...payloadMounts.map(m=>cyl(m.bossRadius,2,[...m.centre,48],48))];
for(const [x,y]of centres){
 upper.push(hull([cyl(6,2,[Math.sign(x)*15,Math.sign(y)*15,48],24),cyl(8.5,2,[x,y,48],32)]));
 upper.push(cyl(8.5,2,[x,y,48],32));
}
const topPlate=emit('upper-motor-plate-3inch',diff(combine(upper),combine([bores([...mountHoles,...adapterHoles,...frameHoles]),...centres.map(([x,y])=>cyl(2.7,4,[x,y,48],32))])),C.black,'frame');
for(const m of payloadMounts)emit(m.insertId.replace(/^ava-v2-/,''),m.insertRoot,[.8,.61,.28],'frame');
const payload=baseline.graph.parts.filter(p=>p.id.startsWith('tv-')&&!p.id.includes('2inch-prop')&&!/motor-\d-three-phase-harness/.test(p.id));
for(const p of payload){
 const m=payloadMounts.find(m=>m.screwId===`ava-v2-context-${p.id}`||m.spacerId===`ava-v2-context-${p.id}`);
 let root;
 if(m&&p.id.includes('spacer'))root=ring(3,1.2,3,[...m.centre,50.5],32);
 else if(m){
  const [x,y]=m.centre;
  root=combine([cyl(1,m.screwLength,[x,y,m.headSeatZ-m.screwLength/2],32),diff(cyl(2,1.5,[x,y,55.75],32),cyl(1,1.5,[x,y,56.3],6))]);
 }else root=move(clone(p.root),[-390,0,0]);
 emit(`context-${p.id}`,root,p.color,'context');
}

// Purchased propellers: representative pitched blades, exact nominal diameter
// and hub envelope. Never use these display meshes as printable flight props.
for(let i=0;i<4;i++){
 const [x,y]=centres[i],hand=i===0||i===3?1:-1;
 const propZ=32.45;
 const blade=move(add('rotate',[hand*13,0,0],[add('extrude',[.75],[],{profile:[[[3,-1.8],[9,-4],[23,-4.6],[35,-1.2],[38.0,.0],[36,2.4],[22,5.5],[8,3.8]]]})]),[0,0,propZ]);
 const rotor=combine([ring(4.9,.8,4.9,[0,0,propZ],32),...[0,120,240].map(a=>add('rotate',[0,0,a],[blade]))]);
 const holes=combine([-2.5,2.5].map(hx=>cyl(1.05,8,[hx,0,propZ],16)));
 emit(`prop-${i+1}-${hand>0?'CCW':'CW'}-HQ-T3x3x3`,move(diff(rotor,holes),[x,y,0]),C.prop,'prop');
 for(const dx of [-2.5,2.5])emit(`prop-${i+1}-M2x7-retainer-${dx<0?1:2}`,combine([cyl(1,7,[x+dx,y,33.5],16),diff(cyl(1.7,1.2,[x+dx,y,29.4],16),cyl(.75,.6,[x+dx,y,28.95],6))]),C.metal,'prop-hardware');
}
const sweeps=centres.map(([x,y])=>ring(38.1,5.1,4.7,[x,y,32.45],128));
const graph={schemaVersion:1,units:'mm',nodes,parts,groups};
fs.writeFileSync(`${out}/design-graph.json`,JSON.stringify(graph,null,2));
fs.writeFileSync(`${out}/design-spec.json`,JSON.stringify({baselineRevision:baseline.revision,baselineSha256:crypto.createHash('sha256').update(baselineBytes).digest('hex'),placement:[650,0,0],oldCentre:[390,0,0],centres,mountHoles,adapterHoles,payloadMounts,frameHoles,battery,sweeps,frameRoot:frame.root,topPlateRoot:topPlate.root,ductRoots:ducts.map(p=>p.root),internalCradle:[86,43,29],batterySize:[82,39,25],batteryCentre:[0,0,7],batteryMassG:141,nominalFrame:[166,166],motorMountFaceZ:47,notes:['New design beside existing assemblies; existing graph is never rewritten.', 'Selected reference: T-Motor F1404 4600KV + HQProp T3x3x3 + GNB11004S140A. Published motor interfaces: diameter17.9, overall16.6, shaft1.5x3, four M2 on PCD9, prop T-mount PCD5. Confirm thread depth against delivered motors; M2x7 prop retainers shown provisionally.','Purchased 3-inch props and GNB11004S140A battery are visible; blade surfaces and motor details are representative, not manufacturing geometry.','Upper motor arms rebuilt for centres at ±41.5 mm; obsolete ±33.2 mm motor tabs removed. Central payload mount pattern and upper plate z47–49 retained.','Payload attachment corrected: four diameter9 frame bosses at ±13/±22.8, full carbon landing pads, M2x12 screws, inserts moved into the frame at z43.5–46.5. Housing and spacer heights unchanged.','Thrust-to-weight and AUW are user targets, not validated performance.']},null,2));
console.log({output:out,nodes:nodes.length,parts:parts.length});
