import fs from 'node:fs';
import crypto from 'node:crypto';

// Additive variant only. Never run the historical replacement generators here.
const out = 'themis-output/v2';
fs.mkdirSync(out, {recursive:true});
const baselineBytes = fs.readFileSync('themis-output/live-scene.json');
const baseline = JSON.parse(baselineBytes);
const nodes=[], parts=[], groups=[{id:'ava-v2',name:'AVA v2 · 3-inch / 1404 · new comparison design'}];
let serial=0;
const C={frame:[.19,.23,.27],orange:[1,.545,.086],metal:[.64,.68,.73],black:[.045,.05,.058],copper:[.65,.3,.10]};
const add=(op,params=[],inputs=[],extra={})=>{const id=`ava-v2-n${++serial}`;nodes.push({id,op,params,inputs,...extra});return id;};
const move=(s,p)=>add('translate',p,[s]);
const box=(d,p)=>move(add('box',d),p);
const cyl=(r,h,p,segments=32)=>move(add('cylinder',[h,r],[],{segments}),p);
function combine(a,op='union'){if(a.length===1)return a[0];const k=a.length>>1;return add(op,[],[combine(a.slice(0,k),op),combine(a.slice(k),op)]);}
const diff=(a,b)=>add('difference',[],[a,b]);
const ring=(ro,ri,h,p,n=32)=>diff(cyl(ro,h,p,n),cyl(ri,h+2,p,n));
const emit=(id,root,color,kind)=>{const p={id:`ava-v2-${id}`,root,color,group:'ava-v2',kind};parts.push(p);return p;};
const centres=[[-41.5,-41.5],[41.5,-41.5],[-41.5,41.5],[41.5,41.5]];
const mountHoles=centres.flatMap(([x,y])=>[[x+4.5,y],[x,y+4.5],[x-4.5,y],[x,y-4.5]]);
const adapterHoles=[[-13,-22.8],[-13,22.8],[13,-22.8],[13,22.8]];
const frameHoles=[[0,-18.03125],[18.03125,0],[0,18.03125],[-18.03125,0]];
const bores=xy=>combine(xy.map(([x,y])=>cyl(1.1,30,[x,y,45],8)));

// Duct bores are circumscribed polygons: their minimum clear ID is 79 mm.
// Small outer datum bumpers bring the otherwise 165 mm duct envelope to 166 mm.
const ducts=centres.map(([x,y],i)=>{
 const tube=ring(41,39.5/Math.cos(Math.PI/64),27,[x,y,33.5],64);
 return emit(`duct-${i+1}`,combine([tube,box([1,4,2],[Math.sign(x)*82.5,y,46]),box([4,1,2],[x,Math.sign(y)*82.5,46])]),C.frame,'frame');
});
const lowerOutline=[[-41.5,-3],[-23,-3],[-23,-25],[-3,-25],[-3,-41.5],[3,-41.5],[3,-25],[23,-25],[23,-3],[41.5,-3],[41.5,3],[23,3],[23,25],[3,25],[3,41.5],[-3,41.5],[-3,25],[-23,25],[-23,3],[-41.5,3]];
const beams=[move(add('extrude',[2],[],{profile:[lowerOutline]}),[0,0,46])];
// Preserve the central mounting coordinates; posts terminate at the unchanged top plate.
for(const [x,y] of frameHoles)beams.push(cyl(3.8,10,[x,y,40],8));
const frame=emit('frame-plate',diff(combine(beams),bores([...adapterHoles,...frameHoles])),C.frame,'frame');

// Open internal cavity 75 x 42 x 30, floor -12..-10, rim at z20.
// End-wall suspension posts occupy the gap between adjacent prop swept volumes.
let tray=diff(box([79,46,32],[0,0,4]),box([75,42,34],[0,0,7]));
tray=diff(tray,combine([-22,22].flatMap(y=>[-22,22].map(x=>box([18,8,5],[x,y,7])))));
tray=combine([tray,...[-38.5,38.5].map(x=>box([2,4,27],[x,0,32.5]))]);
emit('battery-cradle',tray,C.orange,'cradle');

for(let i=0;i<4;i++){
 const [x,y]=centres[i];
 // Inverted motor seats against the upper plate at the original z47 datum.
 // Bell 19.9 x 13.5, base 1.5, exposed shaft 2 => overall 17 mm (z30..47).
 const bell=combine([ring(9.95,8.5,13.5,[x,y,38.75],32),cyl(9.95,1,[x,y,32.5],32)]);
 emit(`motor-${i+1}-bell`,bell,C.black,'motor');
 emit(`motor-${i+1}-stator`,cyl(7,4,[x,y,41],24),C.copper,'motor');
 emit(`motor-${i+1}-mount`,diff(cyl(8,1.5,[x,y,46.25],32),bores(mountHoles.slice(i*4,i*4+4))),C.metal,'motor');
 emit(`motor-${i+1}-shaft`,cyl(.75,17,[x,y,38.5],16),C.metal,'motor');
 for(let j=0;j<4;j++){
  const [hx,hy]=mountHoles[i*4+j];
  emit(`motor-${i+1}-M2-screw-${j+1}`,combine([cyl(1,3.5,[hx,hy,47.25],12),diff(cyl(1.8,1.4,[hx,hy,49.7],12),cyl(.8,.7,[hx,hy,50.15],6))]),C.metal,'hardware');
 }
}

// Copy the exact saved top plate, heatsets and adapter geometry into local coordinates.
const source=new Map(baseline.graph.nodes.map(n=>[n.id,n])),memo=new Map();
function clone(id){if(memo.has(id))return memo.get(id);const n=source.get(id);const root=add(n.op,n.params,n.inputs.map(clone),Object.fromEntries(Object.entries(n).filter(([k])=>!['id','op','params','inputs'].includes(k))));memo.set(id,root);return root;}
// Retain the central plate interface, but remove all obsolete 1104 motor tabs.
// New load-bearing arms and sixteen holes share the motor/duct centre definitions.
const originalTop=baseline.graph.parts.find(p=>p.id==='right-pavo2-carbon-top-plate-reference');
const centrePlate=add('intersection',[],[move(clone(originalTop.root),[-390,0,0]),box([46,50,4],[0,0,48])]);
const upper=[centrePlate];
for(const [x,y]of centres){
 const angle=Math.atan2(y,x),length=Math.hypot(x,y)+40.5;
 upper.push(move(add('rotate',[0,0,angle*180/Math.PI],[add('box',[length,8,2])]),[Math.cos(angle)*length/2,Math.sin(angle)*length/2,48]));
 upper.push(cyl(8.5,2,[x,y,48],32));
}
const topPlate=emit('upper-motor-plate-3inch',diff(combine(upper),bores([...mountHoles,...adapterHoles,...frameHoles])),C.black,'frame');
for(const p of baseline.graph.parts.filter(p=>p.id.startsWith('right-frame-M2x3-heatset-'))){
 emit(p.id.replace(/^right-/,''),move(clone(p.root),[-390,0,0]),p.color,'frame');
}
const payload=baseline.graph.parts.filter(p=>p.id.startsWith('tv-')&&!p.id.includes('2inch-prop')&&!/motor-\d-three-phase-harness/.test(p.id));
for(const p of payload)emit(`context-${p.id}`,move(clone(p.root),[-390,0,0]),p.color,'context');

// References are validation-only: no battery/prop/regulator changes in the payload repo.
const battery=box([70,38,25],[0,0,4.5]);
const sweeps=centres.map(([x,y])=>ring(38.1,.8,2,[x,y,31],128));
const graph={schemaVersion:1,units:'mm',nodes,parts,groups};
fs.writeFileSync(`${out}/design-graph.json`,JSON.stringify(graph,null,2));
fs.writeFileSync(`${out}/design-spec.json`,JSON.stringify({baselineRevision:baseline.revision,baselineSha256:crypto.createHash('sha256').update(baselineBytes).digest('hex'),placement:[650,0,0],oldCentre:[390,0,0],centres,mountHoles,adapterHoles,frameHoles,battery,sweeps,frameRoot:frame.root,topPlateRoot:topPlate.root,ductRoots:ducts.map(p=>p.root),internalCradle:[75,42,30],batterySize:[70,38,25],nominalFrame:[166,166],motorMountFaceZ:47,notes:['New design beside existing assemblies; existing graph is never rewritten.','3-inch props and battery are validation envelopes only. Payload-side changes remain external.','Upper motor arms rebuilt for centres at ±41.5 mm; obsolete ±33.2 mm motor tabs removed. Central payload mount pattern and upper plate z47–49 retained.','Thrust-to-weight and AUW are user targets, not validated performance.']},null,2));
console.log({output:out,nodes:nodes.length,parts:parts.length});
